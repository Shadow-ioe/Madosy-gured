# Madosy Guard 🛡️ (Paper 1.21.x)

طبقات الحماية:
1. **AntiBot**: حد دخول لكل IP، حد حسابات لكل IP، فلتر أسماء البوتات، وضع هجوم تلقائي، وتحقق بكود للاعبين الجدد.
2. **AntiVPN**: فحص IP (ip-api مجاني أو proxycheck) مع كاش، ويمنع VPN/Proxy/الاستضافات والدول المحظورة.
3. **AntiXray**: كشف بالإحصاء (نسبة الخامات النادرة للحجارة + هل الخامة مكشوفة طبيعياً) مع تنبيهات.
4. **Movement**: Fly (ارتفاع/تعليق) وSpeed مع Setback.
5. **Combat**: Reach وAutoClicker وKillAura متعدد الأهداف وNuker.
6. **Chat**: سبام، تكرار، أحرف مكررة، كابس، إعلانات، كلمات ممنوعة.
7. **Commands**: يخفي /pl و/version و bukkit:*، وحد سرعة للأوامر، وحماية OP.
8. **Exploit**: مضاد كراش (كتب/لافتات/عناصر ضخمة، إحداثيات غلط) وحظر كلاينتات الهاك.

## الأوامر (للأدمن)
- الأمر الرئيسي `/shield` (وله اختصارات `/madosy` و `/mg`)
- `/shield status`
- `/shield attack on|off` (قفل يدوي: اللاعبين الجدد ممنوعين)
- `/shield exempt add|remove|list <اسم>`
- `/shield xray <لاعب>` و `/shield vl <لاعب>`
- `/shield reload`

## مهم
- **Paper وفروعه فقط** (Purpur / Pufferfish). مو Spigot ولا Bukkit ولا Folia.
- **Anti-Xray الأقوى**: فعّل المدمج بـ Paper: ملف `config/paper-world-defaults.yml` ← `anticheat: anti-xray: enabled: true` و `engine-mode: 2`. الإضافة تكمّله بالكشف والتنبيه.
- **Velocity**: لازم `player-info-forwarding-mode = "modern"` عشان IP اللاعب الحقيقي يوصل لـ Paper، وإلا الـ VPN والبوتات تشوف IP البروكسي.
- لو لاعب شرعي انحجب: `/shield exempt add اسمه`.
- **DDoS**: الإضافة ما توقف هجمات الشبكة، هذي تحتاج حماية من الاستضافة أو TCPShield/Cloudflare Spectrum.

## الإضافات الجديدة: Freecam / Minimap / Auto-Totem
- **Auto-Totem**: كشف حقيقي من السيرفر، يقيس الزمن بين انفجار التوتم ورجوعه لليد (البشر 150ms+، الهاك 0-100ms).
- **Freecam + Radar + ESP (VisionGuard)**: السيرفر ما يقدر "يكشف" الفري كام لأنه بالكلاينت، لكن يخفي اللاعبين الذين ما لهم خط رؤية عنك، فما في شي يكشفه الفري كام أو الرادار. يستهلك قليل من المعالج (موزع على التكات).
- **Minimap (ClientGuard)**: يرسل أكواد تعطيل الرادار/الكهوف (Xaero / JourneyMap / VoxelMap) ويكشف المودات اللي تسجل قنواتها (تنبيه أو طرد). خريطة التضاريس نفسها ما تنمنع إلا بمنع المود (`detect-action: kick`).
- الكلاينت ممكن يتلاعب ويخفي المود، فهذي حماية قوية مو مطلقة.
