package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Reach, hit-rate (autoclicker), multi-target KillAura, Nuker. Only real melee swings are checked. */
public final class CombatCheck implements Listener {
    private static final class St {
        long lastSwing;
        final ArrayDeque<Long> hits = new ArrayDeque<>();
        final ArrayDeque<long[]> victims = new ArrayDeque<>(); // {time, entityId hash}
        final ArrayDeque<Long> breaks = new ArrayDeque<>();
        double vl;
        long lastAlert;
    }

    private final MadosyGuard plugin;
    private final Map<UUID, St> states = new ConcurrentHashMap<>();

    public CombatCheck(MadosyGuard plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (St s : states.values()) s.vl = Math.max(0, s.vl - 0.3);
        }, 20L, 20L);
    }

    public double vl(UUID id) {
        St s = states.get(id);
        return s == null ? 0 : s.vl;
    }

    private St st(Player p) { return states.computeIfAbsent(p.getUniqueId(), k -> new St()); }

    @EventHandler public void onQuit(PlayerQuitEvent e) { states.remove(e.getPlayer().getUniqueId()); }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) { st(e.getPlayer()).lastSwing = System.currentTimeMillis(); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("combat.enabled", true)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity victim)) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (p.hasPermission("madosyguard.bypass")) return;

        St s = st(p);
        long now = System.currentTimeMillis();
        // damage dealt by other plugins/abilities has no arm swing right before it -> ignore
        if (now - s.lastSwing > 250) return;

        // ---- reach
        if (cfg.getBoolean("combat.reach.enabled", true)) {
            double reach = distanceToBox(p.getEyeLocation(), victim.getBoundingBox());
            double max = cfg.getDouble("combat.reach.max", 4.3);
            if (reach > max) {
                flag(p, s, "Reach (" + String.format("%.2f", reach) + ")", now);
                if (reach > max + 0.7) e.setCancelled(true);
                return;
            }
        }

        // ---- hit rate (autoclicker)
        s.hits.addLast(now);
        while (!s.hits.isEmpty() && now - s.hits.peekFirst() > 1000) s.hits.pollFirst();
        int maxCps = cfg.getInt("combat.max-hits-per-second", 16);
        if (s.hits.size() > maxCps) {
            flag(p, s, "AutoClicker (" + s.hits.size() + " ضربة/ث)", now);
            e.setCancelled(true);
            return;
        }

        // ---- multi-target kill aura
        s.victims.addLast(new long[]{now, victim.getUniqueId().hashCode()});
        while (!s.victims.isEmpty() && now - s.victims.peekFirst()[0] > 200) s.victims.pollFirst();
        Set<Long> distinct = new HashSet<>();
        for (long[] v : s.victims) distinct.add(v[1]);
        if (distinct.size() >= cfg.getInt("combat.multi-target", 3)) {
            flag(p, s, "KillAura (أهداف متعددة)", now);
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("combat.nuker.enabled", true)) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (p.hasPermission("madosyguard.bypass")) return;
        St s = st(p);
        long now = System.currentTimeMillis();
        s.breaks.addLast(now);
        while (!s.breaks.isEmpty() && now - s.breaks.peekFirst() > 1000) s.breaks.pollFirst();
        if (s.breaks.size() > cfg.getInt("combat.nuker.max-breaks-per-second", 28)) {
            flag(p, s, "Nuker (" + s.breaks.size() + " بلوك/ث)", now);
            e.setCancelled(true);
        }
    }

    private void flag(Player p, St s, String what, long now) {
        var cfg = plugin.getConfig();
        s.vl += 1.0;
        if (s.vl >= cfg.getDouble("combat.alert-vl", 3.0) && now - s.lastAlert > 5000) {
            s.lastAlert = now;
            plugin.alert("Combat", p.getName() + " → " + what + " VL " + String.format("%.1f", s.vl));
        }
        double kick = cfg.getDouble("combat.kick-vl", 25.0);
        if (kick > 0 && s.vl >= kick) p.kick(MadosyGuard.mm("<red>تم طردك: اشتباه غش بالقتال."));
    }

    private double distanceToBox(Location eye, BoundingBox box) {
        Vector v = eye.toVector();
        double x = Math.max(box.getMinX(), Math.min(v.getX(), box.getMaxX()));
        double y = Math.max(box.getMinY(), Math.min(v.getY(), box.getMaxY()));
        double z = Math.max(box.getMinZ(), Math.min(v.getZ(), box.getMaxZ()));
        return v.distance(new Vector(x, y, z));
    }
}
