package dev.madosy.guard;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class AntiVpn implements Listener {
    private record Entry(boolean block, String country, long expires) { }

    private final MadosyGuard plugin;
    private final Map<String, Entry> cache = new ConcurrentHashMap<>();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
    private volatile int blocked = 0;

    public AntiVpn(MadosyGuard plugin) { this.plugin = plugin; }

    public void clearCache() { cache.clear(); }
    public int blockedCount() { return blocked; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("antivpn.enabled", true)) return;
        if (e.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) return;
        InetAddress addr = e.getAddress();
        if (addr.isAnyLocalAddress() || addr.isLoopbackAddress() || addr.isSiteLocalAddress() || addr.isLinkLocalAddress()) return;
        if (plugin.isExempt(e.getName())) return;
        String ip = addr.getHostAddress();
        if (c.getStringList("antivpn.exempt-ips").contains(ip)) return;

        Entry en = lookup(ip);
        if (en == null) {
            if (!c.getBoolean("antivpn.fail-open", true)) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plugin.msg("antivpn.kick-message"));
            }
            return;
        }
        if (en.block()) {
            blocked++;
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plugin.msg("antivpn.kick-message"));
            plugin.alert("AntiVPN", e.getName() + " (" + ip + ", " + en.country() + ") تم منعه: VPN/Proxy/استضافة");
        }
    }

    private Entry lookup(String ip) {
        long now = System.currentTimeMillis();
        Entry cached = cache.get(ip);
        if (cached != null && cached.expires() > now) return cached;

        FileConfiguration c = plugin.getConfig();
        String provider = c.getString("antivpn.provider", "ip-api");
        boolean proxycheck = provider.equalsIgnoreCase("proxycheck");
        boolean blockHosting = c.getBoolean("antivpn.block-hosting", true);
        long cacheMs = c.getLong("antivpn.cache-minutes", 360) * 60_000L;
        int timeout = c.getInt("antivpn.timeout-ms", 3000);
        try {
            String url;
            if (proxycheck) {
                String key = c.getString("antivpn.proxycheck-key", "");
                url = "https://proxycheck.io/v2/" + ip + "?vpn=1&asn=1" + (key.isBlank() ? "" : "&key=" + key);
            } else {
                url = "http://ip-api.com/json/" + ip + "?fields=status,message,countryCode,proxy,hosting";
            }
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofMillis(timeout)).GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) return null;
            JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();

            boolean block;
            String country = "??";
            if (proxycheck) {
                JsonObject d = o.has(ip) && o.get(ip).isJsonObject() ? o.getAsJsonObject(ip) : null;
                if (d == null) return null;
                block = d.has("proxy") && "yes".equalsIgnoreCase(d.get("proxy").getAsString());
                if (d.has("isocode")) country = d.get("isocode").getAsString();
            } else {
                if (!o.has("status") || !"success".equals(o.get("status").getAsString())) return null;
                boolean proxy = o.has("proxy") && o.get("proxy").getAsBoolean();
                boolean hosting = o.has("hosting") && o.get("hosting").getAsBoolean();
                block = proxy || (blockHosting && hosting);
                if (o.has("countryCode")) country = o.get("countryCode").getAsString();
            }
            for (String cc : c.getStringList("antivpn.blocked-countries")) {
                if (cc.equalsIgnoreCase(country)) block = true;
            }
            Entry en = new Entry(block, country, now + cacheMs);
            cache.put(ip, en);
            return en;
        } catch (Exception ex) {
            return null;
        }
    }
}
