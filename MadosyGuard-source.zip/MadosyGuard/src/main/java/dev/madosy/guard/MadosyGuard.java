package dev.madosy.guard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class MadosyGuard extends JavaPlugin {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private AntiBot antiBot;
    private AntiVpn antiVpn;
    private AntiXray antiXray;
    private MovementCheck movement;
    private CombatCheck combat;
    private VisionGuard vision;
    private AutoTotemCheck autoTotem;

    private final Set<String> exempt = ConcurrentHashMap.newKeySet();
    private File exemptFile;
    private long installTime;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadExempt();
        loadInstallTime();

        antiBot = new AntiBot(this, installTime);
        antiVpn = new AntiVpn(this);
        antiXray = new AntiXray(this);
        movement = new MovementCheck(this);
        combat = new CombatCheck(this);
        vision = new VisionGuard(this);
        autoTotem = new AutoTotemCheck(this);

        Bukkit.getPluginManager().registerEvents(antiBot, this);
        Bukkit.getPluginManager().registerEvents(antiVpn, this);
        Bukkit.getPluginManager().registerEvents(antiXray, this);
        Bukkit.getPluginManager().registerEvents(movement, this);
        Bukkit.getPluginManager().registerEvents(combat, this);
        Bukkit.getPluginManager().registerEvents(vision, this);
        Bukkit.getPluginManager().registerEvents(autoTotem, this);
        Bukkit.getPluginManager().registerEvents(new ClientGuard(this), this);
        Bukkit.getPluginManager().registerEvents(new ChatGuard(this), this);
        Bukkit.getPluginManager().registerEvents(new CommandGuard(this), this);
        Bukkit.getPluginManager().registerEvents(new ExploitGuard(this), this);

        ShieldCommand cmd = new ShieldCommand(this);
        getCommand("shield").setExecutor(cmd);
        getCommand("shield").setTabCompleter(cmd);

        getLogger().info("MadosyGuard enabled.");
    }

    @Override
    public void onDisable() {
        if (antiBot != null) antiBot.save();
        if (vision != null) vision.shutdown();
    }

    public void reload() {
        reloadConfig();
        antiBot.reloadPatterns();
        antiVpn.clearCache();
        antiXray.reloadSets();
        vision.restart();
    }

    public AntiBot antiBot() { return antiBot; }
    public AntiVpn antiVpn() { return antiVpn; }
    public AntiXray antiXray() { return antiXray; }
    public MovementCheck movement() { return movement; }
    public CombatCheck combat() { return combat; }
    public VisionGuard vision() { return vision; }
    public AutoTotemCheck autoTotem() { return autoTotem; }

    // ---------------------------------------------------------------- helpers
    public Component msg(String path) {
        return MM.deserialize(getConfig().getString(path, "<red>" + path));
    }

    public static Component mm(String s) { return MM.deserialize(s); }

    public void alert(String module, String text) {
        String prefix = getConfig().getString("alerts.prefix", "<dark_gray>[<red>Madosy<dark_gray>] ");
        Component c = MM.deserialize(prefix + "<yellow>" + module + " <dark_gray>» <white>" + MM.escapeTags(text));
        Runnable r = () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("madosyguard.alerts")) p.sendMessage(c);
            }
            if (getConfig().getBoolean("alerts.console", true)) {
                getLogger().warning("[" + module + "] " + text);
            }
        };
        if (Bukkit.isPrimaryThread()) r.run();
        else Bukkit.getScheduler().runTask(this, r);
    }

    // ---------------------------------------------------------------- exempt list (names)
    public boolean isExempt(String name) { return name != null && exempt.contains(name.toLowerCase()); }

    public Set<String> exemptNames() { return exempt; }

    public void setExempt(String name, boolean on) {
        if (on) exempt.add(name.toLowerCase()); else exempt.remove(name.toLowerCase());
        YamlConfiguration y = new YamlConfiguration();
        y.set("names", List.copyOf(exempt));
        try { y.save(exemptFile); } catch (IOException e) { getLogger().warning("exempt.yml: " + e.getMessage()); }
    }

    private void loadExempt() {
        exemptFile = new File(getDataFolder(), "exempt.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(exemptFile);
        for (String n : y.getStringList("names")) exempt.add(n.toLowerCase());
    }

    private void loadInstallTime() {
        File f = new File(getDataFolder(), "data.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        if (!y.contains("install-time")) {
            y.set("install-time", System.currentTimeMillis());
            try { y.save(f); } catch (IOException e) { getLogger().warning("data.yml: " + e.getMessage()); }
        }
        installTime = y.getLong("install-time");
    }
}
