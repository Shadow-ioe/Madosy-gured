package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Anti-Freecam / Anti-Radar / Anti-ESP: players that have no line of sight to you are hidden from your
 * client, so hacks (freecam, radar, wallhack) have nothing to reveal. Work is spread over many ticks.
 */
public final class VisionGuard implements Listener {
    private final MadosyGuard plugin;
    private final Map<UUID, Set<UUID>> hidden = new HashMap<>();
    private List<Player> snapshot = new ArrayList<>();
    private int cursor = 0;
    private BukkitTask task;

    public VisionGuard(MadosyGuard plugin) {
        this.plugin = plugin;
        restart();
    }

    public void restart() {
        if (task != null) { task.cancel(); task = null; }
        if (!plugin.getConfig().getBoolean("vision.enabled", true)) {
            unhideEveryone();
            return;
        }
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 1L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        unhideEveryone();
    }

    public int hiddenPairs() {
        int n = 0;
        for (Set<UUID> s : hidden.values()) n += s.size();
        return n;
    }

    private void unhideEveryone() {
        for (Map.Entry<UUID, Set<UUID>> en : hidden.entrySet()) {
            Player viewer = Bukkit.getPlayer(en.getKey());
            if (viewer == null) continue;
            for (UUID t : en.getValue()) {
                Player target = Bukkit.getPlayer(t);
                if (target != null) viewer.showEntity(plugin, target);
            }
        }
        hidden.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        hidden.remove(id);
        for (Set<UUID> s : hidden.values()) s.remove(id);
    }

    private void tick() {
        if (cursor >= snapshot.size()) {
            snapshot = new ArrayList<>(Bukkit.getOnlinePlayers());
            cursor = 0;
            if (snapshot.isEmpty()) return;
        }
        int batch = Math.max(1, plugin.getConfig().getInt("vision.viewers-per-tick", 6));
        for (int i = 0; i < batch && cursor < snapshot.size(); i++, cursor++) {
            Player v = snapshot.get(cursor);
            if (v.isOnline()) process(v);
        }
    }

    private void process(Player viewer) {
        var cfg = plugin.getConfig();
        double maxDist = cfg.getDouble("vision.max-distance", 64);
        double always = cfg.getDouble("vision.always-visible-distance", 8);
        boolean bypass = viewer.getGameMode() == GameMode.SPECTATOR || viewer.hasPermission("madosyguard.bypass");
        Set<UUID> hs = hidden.computeIfAbsent(viewer.getUniqueId(), k -> new HashSet<>());
        Location eye = viewer.getEyeLocation();
        World w = viewer.getWorld();

        for (Player target : snapshot) {
            if (target == viewer || !target.isOnline()) continue;
            boolean hide = false;
            if (!bypass && target.getWorld().equals(w) && target.getGameMode() != GameMode.SPECTATOR) {
                double d2 = eye.distanceSquared(target.getLocation());
                if (d2 > always * always && d2 <= maxDist * maxDist) {
                    hide = !visible(eye, target);
                }
            }
            if (hide) {
                if (hs.add(target.getUniqueId())) viewer.hideEntity(plugin, target);
            } else {
                if (hs.remove(target.getUniqueId())) viewer.showEntity(plugin, target);
            }
        }
    }

    private boolean visible(Location eye, Player target) {
        Location base = target.getLocation();
        // perpendicular horizontal offset to sample both shoulders
        Vector toT = base.toVector().subtract(eye.toVector());
        Vector side = new Vector(-toT.getZ(), 0, toT.getX());
        if (side.lengthSquared() > 0.0001) side.normalize().multiply(0.35); else side = new Vector(0.35, 0, 0);

        Location[] pts = {
                base.clone().add(0, 0.2, 0),
                base.clone().add(0, 0.9, 0),
                base.clone().add(0, 1.6, 0),
                base.clone().add(side).add(0, 0.9, 0),
                base.clone().subtract(side).add(0, 0.9, 0)
        };
        for (Location p : pts) {
            if (clear(eye, p)) return true;
        }
        return false;
    }

    private boolean clear(Location eye, Location point) {
        Vector dir = point.toVector().subtract(eye.toVector());
        double dist = dir.length();
        if (dist < 0.5) return true;
        RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, dir.normalize(), dist, FluidCollisionMode.NEVER, true);
        if (r == null || r.getHitBlock() == null) return true;
        Block b = r.getHitBlock();
        // glass, leaves, fences etc. do not hide a player
        return !b.getType().isOccluding();
    }
}
