package dev.madosy.guard;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.regex.Pattern;

public final class AntiBot implements Listener {
    private static final String CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    private static final class Pending {
        final String code;
        final long deadline;
        int attempts = 0;
        Pending(String code, long deadline) { this.code = code; this.deadline = deadline; }
    }

    private final MadosyGuard plugin;
    private final long installTime;
    private final SecureRandom rnd = new SecureRandom();

    private final Map<String, Deque<Long>> ipJoins = new ConcurrentHashMap<>();
    private final Deque<Long> globalJoins = new ConcurrentLinkedDeque<>();
    private final Map<String, Set<String>> ipAccounts = new ConcurrentHashMap<>();
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();
    private final Set<UUID> verified = ConcurrentHashMap.newKeySet();
    private final List<Pattern> namePatterns = new ArrayList<>();

    private volatile long attackUntil = 0;
    private volatile boolean manualLockdown = false;
    private int blockedCount = 0;

    private final File verifiedFile, ipsFile;

    public AntiBot(MadosyGuard plugin, long installTime) {
        this.plugin = plugin;
        this.installTime = installTime;
        this.verifiedFile = new File(plugin.getDataFolder(), "verified.yml");
        this.ipsFile = new File(plugin.getDataFolder(), "ips.yml");
        load();
        reloadPatterns();

        // verification timer (titles + timeouts)
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickVerification, 20L, 20L);
        // periodic cleanup + save
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            ipJoins.entrySet().removeIf(en -> {
                Deque<Long> d = en.getValue();
                Long last = d.peekLast();
                return last == null || now - last > 120_000;
            });
            save();
        }, 20L * 300, 20L * 300);
    }

    // ------------------------------------------------------------------ state
    public boolean underAttack() { return manualLockdown || System.currentTimeMillis() < attackUntil; }

    public void setLockdown(boolean on) {
        manualLockdown = on;
        if (!on) attackUntil = 0;
    }

    public int blockedCount() { return blockedCount; }
    public int recentJoins() { return globalJoins.size(); }
    public int pendingVerifications() { return pending.size(); }
    public boolean manualLockdown() { return manualLockdown; }

    public void reloadPatterns() {
        namePatterns.clear();
        for (String rx : plugin.getConfig().getStringList("antibot.name-blacklist-regex")) {
            try { namePatterns.add(Pattern.compile(rx)); }
            catch (Exception ex) { plugin.getLogger().warning("Bad regex: " + rx); }
        }
    }

    private boolean isKnown(UUID id) {
        if (verified.contains(id)) return true;
        org.bukkit.OfflinePlayer op = Bukkit.getOfflinePlayer(id);
        return op.hasPlayedBefore() && op.getFirstPlayed() > 0 && op.getFirstPlayed() < installTime;
    }

    // ------------------------------------------------------------------ login checks
    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("antibot.enabled", true)) return;
        if (e.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) return;

        String name = e.getName();
        String ip = e.getAddress().getHostAddress();
        if (plugin.isExempt(name)) return;
        long now = System.currentTimeMillis();

        // global join rate -> automatic attack mode
        globalJoins.addLast(now);
        while (!globalJoins.isEmpty() && now - globalJoins.peekFirst() > 10_000) globalJoins.pollFirst();
        int trigger = c.getInt("antibot.attack-mode.joins-per-10s", 8);
        if (globalJoins.size() >= trigger && !underAttack()) {
            long dur = c.getLong("antibot.attack-mode.duration-seconds", 120);
            attackUntil = now + dur * 1000L;
            plugin.alert("AntiBot", "🚨 هجوم بوتات مكتشف (" + globalJoins.size() + " دخول/10ث). وضع الحماية شغال " + dur + " ثانية.");
        }

        // per-IP join speed
        Deque<Long> dq = ipJoins.computeIfAbsent(ip, k -> new ConcurrentLinkedDeque<>());
        dq.addLast(now);
        while (!dq.isEmpty() && now - dq.peekFirst() > 60_000) dq.pollFirst();
        if (dq.size() > c.getInt("antibot.max-joins-per-ip-per-minute", 4)) {
            deny(e, "antibot.messages.too-fast");
            return;
        }

        // bad names
        for (Pattern p : namePatterns) {
            if (p.matcher(name).matches()) {
                deny(e, "antibot.messages.bad-name");
                return;
            }
        }

        // accounts per IP
        Set<String> set = ipAccounts.computeIfAbsent(ip, k -> ConcurrentHashMap.newKeySet());
        String ln = name.toLowerCase();
        if (!set.contains(ln) && set.size() >= c.getInt("antibot.max-accounts-per-ip", 3)) {
            deny(e, "antibot.messages.too-many-accounts");
            return;
        }

        // attack mode: only known players
        if (underAttack() && !isKnown(e.getUniqueId())) {
            deny(e, "antibot.messages.attack");
            return;
        }
        set.add(ln);
    }

    private void deny(AsyncPlayerPreLoginEvent e, String msgPath) {
        blockedCount++;
        e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plugin.msg(msgPath));
    }

    // ------------------------------------------------------------------ verification (new players)
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("antibot.enabled", true) || !c.getBoolean("antibot.verification.enabled", true)) return;
        Player p = e.getPlayer();
        if (plugin.isExempt(p.getName()) || p.hasPermission("madosyguard.bypass")) return;
        if (isKnown(p.getUniqueId())) return;

        int len = Math.max(3, c.getInt("antibot.verification.code-length", 4));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(CODE_CHARS.charAt(rnd.nextInt(CODE_CHARS.length())));
        long timeout = c.getLong("antibot.verification.timeout-seconds", 30) * 1000L;
        pending.put(p.getUniqueId(), new Pending(sb.toString(), System.currentTimeMillis() + timeout));
        p.setInvulnerable(true);
        p.sendMessage(MadosyGuard.mm("<yellow>🛡 تحقق سريع: <white>اكتب الكود الظاهر على <gold>الشاشة <white>في الشات."));
        showCode(p, pending.get(p.getUniqueId()));
    }

    private void showCode(Player p, Pending pd) {
        long left = Math.max(0, (pd.deadline - System.currentTimeMillis()) / 1000);
        p.showTitle(Title.title(
                MadosyGuard.mm("<gold><bold>" + pd.code),
                MadosyGuard.mm("<gray>اكتب الكود بالشات <dark_gray>(" + left + "s)"),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ZERO)));
    }

    private void tickVerification() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Pending> en : new ArrayList<>(pending.entrySet())) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null) { pending.remove(en.getKey()); continue; }
            if (now > en.getValue().deadline) {
                pending.remove(en.getKey());
                p.setInvulnerable(false);
                blockedCount++;
                p.kick(plugin.msg("antibot.messages.verify-failed"));
            } else {
                showCode(p, en.getValue());
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Pending pd = pending.get(p.getUniqueId());
        if (pd == null) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        if (text.equalsIgnoreCase(pd.code)) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                pending.remove(p.getUniqueId());
                verified.add(p.getUniqueId());
                p.setInvulnerable(false);
                p.clearTitle();
                p.sendMessage(MadosyGuard.mm("<green>✔ تم التحقق. أهلاً بك!"));
                save();
            });
        } else {
            pd.attempts++;
            int max = plugin.getConfig().getInt("antibot.verification.max-attempts", 3);
            if (pd.attempts >= max) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    pending.remove(p.getUniqueId());
                    p.setInvulnerable(false);
                    blockedCount++;
                    p.kick(plugin.msg("antibot.messages.verify-failed"));
                });
            } else {
                p.sendMessage(MadosyGuard.mm("<red>كود غلط. المحاولات المتبقية: " + (max - pd.attempts)));
            }
        }
    }

    private boolean frozen(Player p) { return pending.containsKey(p.getUniqueId()); }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!frozen(e.getPlayer())) return;
        if (e.getTo() != null && (e.getFrom().getX() != e.getTo().getX()
                || e.getFrom().getY() != e.getTo().getY() || e.getFrom().getZ() != e.getTo().getZ())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCmd(PlayerCommandPreprocessEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (pending.remove(e.getPlayer().getUniqueId()) != null) e.getPlayer().setInvulnerable(false);
    }

    public void unverify(UUID id) { verified.remove(id); save(); }

    // ------------------------------------------------------------------ persistence
    private synchronized void load() {
        YamlConfiguration v = YamlConfiguration.loadConfiguration(verifiedFile);
        for (String s : v.getStringList("uuids")) {
            try { verified.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) { }
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(ipsFile);
        for (String key : y.getKeys(false)) {
            ipAccounts.put(key.replace('_', '.').replace('-', ':'), new HashSet<>(y.getStringList(key)));
        }
    }

    public synchronized void save() {
        try {
            YamlConfiguration v = new YamlConfiguration();
            List<String> ids = new ArrayList<>();
            for (UUID u : verified) ids.add(u.toString());
            v.set("uuids", ids);
            v.save(verifiedFile);

            YamlConfiguration y = new YamlConfiguration();
            for (Map.Entry<String, Set<String>> en : ipAccounts.entrySet()) {
                y.set(en.getKey().replace('.', '_').replace(':', '-'), new ArrayList<>(en.getValue()));
            }
            y.save(ipsFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("AntiBot save failed: " + ex.getMessage());
        }
    }
}
