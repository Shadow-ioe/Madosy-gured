package dev.madosy.guard;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/** Spam / flood / caps / advertising / bad words. */
public final class ChatGuard implements Listener {
    private static final Pattern IPV4 = Pattern.compile("\\b(?:\\d{1,3}[.,]){3}\\d{1,3}(?::\\d{1,5})?\\b");
    private static final Pattern DOMAIN = Pattern.compile(
            "(?i)\\b[a-z0-9-]{2,}\\s?(?:\\.|\\(dot\\)|\\[dot\\])\\s?(?:com|net|org|gg|io|me|xyz|club|fun|pro|cc|tk|ml|gq|ga|cf|top|online|site|store|host|cloud|aternos\\.me)\\b");
    private static final Pattern REPEAT = Pattern.compile("(.)\\1{7,}");

    private static final class St {
        long lastMsg;
        String lastText = "";
        long lastTextTime;
        double vl;
    }

    private final MadosyGuard plugin;
    private final Map<UUID, St> states = new ConcurrentHashMap<>();

    public ChatGuard(MadosyGuard plugin) { this.plugin = plugin; }

    @EventHandler public void onQuit(PlayerQuitEvent e) { states.remove(e.getPlayer().getUniqueId()); }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("chat.enabled", true)) return;
        Player p = e.getPlayer();
        if (p.hasPermission("madosyguard.bypass") || plugin.isExempt(p.getName())) return;

        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        long now = System.currentTimeMillis();
        St s = states.computeIfAbsent(p.getUniqueId(), k -> new St());

        // too long
        if (text.length() > cfg.getInt("chat.max-length", 256)) { block(e, p, s, "الرسالة طويلة جداً", false); return; }

        // too fast
        if (now - s.lastMsg < cfg.getLong("chat.min-delay-ms", 700)) { block(e, p, s, "لا ترسل الرسائل بسرعة", false); return; }

        String norm = text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        // repeated message
        if (cfg.getBoolean("chat.block-repeat", true) && norm.equals(s.lastText)
                && now - s.lastTextTime < cfg.getLong("chat.repeat-window-ms", 10_000)) {
            block(e, p, s, "لا تكرر نفس الرسالة", false);
            return;
        }

        // char flood
        if (REPEAT.matcher(text).find()) { block(e, p, s, "حروف مكررة كثير", false); return; }

        // caps
        if (text.length() >= cfg.getInt("chat.caps-min-length", 10)) {
            int letters = 0, upper = 0;
            for (char ch : text.toCharArray()) {
                if (Character.isLetter(ch)) { letters++; if (Character.isUpperCase(ch)) upper++; }
            }
            if (letters >= 8 && upper * 100 / letters >= cfg.getInt("chat.caps-percent", 70)) {
                block(e, p, s, "لا تستخدم الأحرف الكبيرة بكثرة", false);
                return;
            }
        }

        // advertising
        if (cfg.getBoolean("chat.block-ads", true)) {
            String check = norm;
            boolean ad = IPV4.matcher(check).find() || DOMAIN.matcher(check).find();
            if (ad) {
                for (String ok : cfg.getStringList("chat.allowed-domains")) {
                    if (check.contains(ok.toLowerCase(Locale.ROOT))) { ad = false; break; }
                }
            }
            if (ad) { block(e, p, s, "الإعلانات ممنوعة", true); return; }
        }

        // bad words
        List<String> bad = cfg.getStringList("chat.blocked-words");
        for (String w : bad) {
            if (!w.isBlank() && norm.contains(w.toLowerCase(Locale.ROOT))) {
                block(e, p, s, "كلمة ممنوعة", true);
                return;
            }
        }

        s.lastMsg = now;
        s.lastText = norm;
        s.lastTextTime = now;
    }

    private void block(AsyncChatEvent e, Player p, St s, String reason, boolean alert) {
        e.setCancelled(true);
        p.sendMessage(MadosyGuard.mm("<red>🛡 " + reason));
        if (alert) {
            s.vl += 1;
            plugin.alert("Chat", p.getName() + " → " + reason + " (VL " + (int) s.vl + ")");
            int kick = plugin.getConfig().getInt("chat.kick-after-violations", 5);
            if (kick > 0 && s.vl >= kick) {
                s.vl = 0;
                org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> p.kick(MadosyGuard.mm("<red>تم طردك: مخالفات شات متكررة.")));
            }
        }
    }
}
