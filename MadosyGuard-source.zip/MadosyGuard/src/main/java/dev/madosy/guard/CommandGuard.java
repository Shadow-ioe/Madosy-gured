package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Hides plugin list/version, blocks namespaced commands, rate-limits commands, guards OP. */
public final class CommandGuard implements Listener {
    private final MadosyGuard plugin;
    private final Map<UUID, ArrayDeque<Long>> rate = new ConcurrentHashMap<>();

    public CommandGuard(MadosyGuard plugin) {
        this.plugin = plugin;
        // OP guard: only players in antiop.allowed may be operators
        Bukkit.getScheduler().runTaskTimer(plugin, this::checkOps, 100L, 100L);
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { rate.remove(e.getPlayer().getUniqueId()); }

    private boolean admin(Player p) { return p.hasPermission("madosyguard.admin"); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("commands.enabled", true)) return;
        Player p = e.getPlayer();
        if (admin(p)) return;

        String msg = e.getMessage();
        String first = msg.startsWith("/") ? msg.substring(1) : msg;
        first = first.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);

        // rate limit
        long now = System.currentTimeMillis();
        ArrayDeque<Long> dq = rate.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        dq.addLast(now);
        while (!dq.isEmpty() && now - dq.peekFirst() > 1000) dq.pollFirst();
        if (dq.size() > cfg.getInt("commands.max-per-second", 6)) {
            e.setCancelled(true);
            plugin.alert("Commands", p.getName() + " يرسل أوامر بسرعة (" + dq.size() + "/ث)");
            return;
        }

        boolean blocked = cfg.getBoolean("commands.block-namespaced", true) && first.contains(":");
        if (!blocked) {
            for (String b : cfg.getStringList("commands.blocked")) {
                if (first.equals(b.toLowerCase(Locale.ROOT))) { blocked = true; break; }
            }
        }
        if (blocked) {
            e.setCancelled(true);
            p.sendMessage(MadosyGuard.mm("<red>Unknown command. Type \"/help\" for help."));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTab(PlayerCommandSendEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("commands.enabled", true) || admin(e.getPlayer())) return;
        List<String> blocked = cfg.getStringList("commands.blocked");
        boolean ns = cfg.getBoolean("commands.block-namespaced", true);
        e.getCommands().removeIf(c -> (ns && c.contains(":")) || blocked.contains(c.toLowerCase(Locale.ROOT)));
    }

    private void checkOps() {
        var cfg = plugin.getConfig();
        List<String> allowed = cfg.getStringList("antiop.allowed");
        if (!cfg.getBoolean("antiop.enabled", false) || allowed.isEmpty()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!p.isOp()) continue;
            boolean ok = false;
            for (String n : allowed) if (n.equalsIgnoreCase(p.getName())) { ok = true; break; }
            if (!ok) {
                plugin.alert("AntiOP", p.getName() + " عنده OP وهو مو بالقائمة المسموحة!");
                if (cfg.getBoolean("antiop.deop", true)) p.setOp(false);
            }
        }
    }
}
