package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class ShieldCommand implements CommandExecutor, TabCompleter {
    private final MadosyGuard plugin;

    public ShieldCommand(MadosyGuard plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String sub = a.length == 0 ? "status" : a[0].toLowerCase();
        switch (sub) {
            case "status" -> {
                AntiBot ab = plugin.antiBot();
                s.sendMessage(MadosyGuard.mm("<red><bold>🛡 Madosy Guard <gray>— الحالة"));
                s.sendMessage(MadosyGuard.mm("<gray>وضع الهجوم: " + (ab.underAttack() ? "<red>شغال" : "<green>طافي")
                        + (ab.manualLockdown() ? " <yellow>(يدوي)" : "")));
                s.sendMessage(MadosyGuard.mm("<gray>دخولات آخر 10ث: <white>" + ab.recentJoins()
                        + " <gray>| محظور بوتات: <white>" + ab.blockedCount()
                        + " <gray>| بانتظار التحقق: <white>" + ab.pendingVerifications()));
                s.sendMessage(MadosyGuard.mm("<gray>محظور VPN: <white>" + plugin.antiVpn().blockedCount()
                        + " <gray>| لاعبين مخفيين (Vision): <white>" + plugin.vision().hiddenPairs()));
            }
            case "attack" -> {
                if (a.length < 2) { s.sendMessage(MadosyGuard.mm("<red>/shield attack <on|off>")); return true; }
                boolean on = a[1].equalsIgnoreCase("on");
                plugin.antiBot().setLockdown(on);
                s.sendMessage(MadosyGuard.mm(on ? "<red>🔒 تم تفعيل القفل (اللاعبين الجدد ممنوعين)." : "<green>🔓 تم إيقاف القفل."));
            }
            case "exempt" -> {
                if (a.length < 2) { s.sendMessage(MadosyGuard.mm("<red>/shield exempt <add|remove|list> [اسم]")); return true; }
                switch (a[1].toLowerCase()) {
                    case "list" -> s.sendMessage(MadosyGuard.mm("<gray>المستثنين: <white>" + String.join(", ", plugin.exemptNames())));
                    case "add", "remove" -> {
                        if (a.length < 3) { s.sendMessage(MadosyGuard.mm("<red>اكتب الاسم.")); return true; }
                        plugin.setExempt(a[2], a[1].equalsIgnoreCase("add"));
                        s.sendMessage(MadosyGuard.mm("<green>✔ تم."));
                    }
                    default -> s.sendMessage(MadosyGuard.mm("<red>/shield exempt <add|remove|list> [اسم]"));
                }
            }
            case "xray" -> {
                if (a.length < 2) { s.sendMessage(MadosyGuard.mm("<red>/shield xray <لاعب>")); return true; }
                OfflinePlayer op = Bukkit.getOfflinePlayer(a[1]);
                s.sendMessage(MadosyGuard.mm("<yellow>X-Ray <white>" + a[1] + "<gray>: " + plugin.antiXray().report(op.getUniqueId())));
            }
            case "vl" -> {
                if (a.length < 2) { s.sendMessage(MadosyGuard.mm("<red>/shield vl <لاعب>")); return true; }
                Player p = Bukkit.getPlayerExact(a[1]);
                if (p == null) { s.sendMessage(MadosyGuard.mm("<red>اللاعب مو أونلاين.")); return true; }
                s.sendMessage(MadosyGuard.mm("<yellow>" + p.getName() + " <gray>حركة VL: <white>"
                        + String.format("%.1f", plugin.movement().vl(p.getUniqueId()))
                        + " <gray>| قتال VL: <white>" + String.format("%.1f", plugin.combat().vl(p.getUniqueId()))
                        + " <gray>| توتم VL: <white>" + String.format("%.1f", plugin.autoTotem().vl(p.getUniqueId()))));
            }
            case "reload" -> {
                plugin.reload();
                s.sendMessage(MadosyGuard.mm("<green>✔ تم إعادة تحميل الإعدادات."));
            }
            default -> s.sendMessage(MadosyGuard.mm("<gray>/shield <status|attack|exempt|xray|vl|reload>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("status", "attack", "exempt", "xray", "vl", "reload")) if (x.startsWith(a[0].toLowerCase())) out.add(x);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("attack")) {
            out.add("on"); out.add("off");
        } else if (a.length == 2 && a[0].equalsIgnoreCase("exempt")) {
            out.add("add"); out.add("remove"); out.add("list");
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("xray") || a[0].equalsIgnoreCase("vl"))) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        return out;
    }
}
