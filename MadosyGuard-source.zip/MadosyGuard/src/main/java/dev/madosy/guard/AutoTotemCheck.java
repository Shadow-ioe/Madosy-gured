package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Auto-totem detection: after a totem pops, measures how many ticks pass until the same hand
 * holds a totem again. Humans need ~150ms+ (3+ ticks); auto-totem hacks do it in 0-2 ticks.
 */
public final class AutoTotemCheck implements Listener {
    private final MadosyGuard plugin;
    private final Map<UUID, Double> vl = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> streak = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastAlert = new ConcurrentHashMap<>();

    public AutoTotemCheck(MadosyGuard plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, Double> en : vl.entrySet()) en.setValue(Math.max(0, en.getValue() - 0.5));
        }, 20L * 30, 20L * 30);
    }

    public double vl(UUID id) { return vl.getOrDefault(id, 0.0); }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        vl.remove(id); streak.remove(id); lastAlert.remove(id);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPop(EntityResurrectEvent e) {
        if (!plugin.getConfig().getBoolean("autototem.enabled", true)) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.hasPermission("madosyguard.bypass")) return;

        EquipmentSlot hand = e.getHand();
        final EquipmentSlot slot = hand == EquipmentSlot.HAND ? EquipmentSlot.HAND : EquipmentSlot.OFF_HAND;

        new BukkitRunnable() {
            int waited = 0;

            @Override
            public void run() {
                waited++;
                if (!p.isOnline() || p.isDead()) { cancel(); return; }
                ItemStack it = slot == EquipmentSlot.HAND
                        ? p.getInventory().getItemInMainHand()
                        : p.getInventory().getItemInOffHand();
                if (it.getType() == Material.TOTEM_OF_UNDYING) {
                    cancel();
                    evaluate(p, waited);
                } else if (waited >= 40) {
                    cancel();
                    streak.put(p.getUniqueId(), 0);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void evaluate(Player p, int ticks) {
        var cfg = plugin.getConfig();
        UUID id = p.getUniqueId();
        int instant = cfg.getInt("autototem.instant-ticks", 2);
        int fast = cfg.getInt("autototem.fast-ticks", 4);

        double add = 0;
        if (ticks <= instant) add = 2.0;
        else if (ticks <= fast) add = 0.5;

        if (add > 0) {
            int st = streak.merge(id, 1, Integer::sum);
            if (st >= 3) add += 1.5;
        } else {
            streak.put(id, 0);
            return;
        }

        double total = vl.merge(id, add, Double::sum);
        long now = System.currentTimeMillis();
        if (total >= cfg.getDouble("autototem.alert-vl", 3.0) && now - lastAlert.getOrDefault(id, 0L) > 5000) {
            lastAlert.put(id, now);
            plugin.alert("AutoTotem", p.getName() + " أعاد التوتم بعد " + (ticks * 50) + "ms (" + ticks
                    + " tick) | VL " + String.format("%.1f", total));
        }
        double kick = cfg.getDouble("autototem.kick-vl", 0);
        if (kick > 0 && total >= kick) {
            p.kick(MadosyGuard.mm("<red>تم طردك: اشتباه Auto-Totem."));
        }
    }
}
