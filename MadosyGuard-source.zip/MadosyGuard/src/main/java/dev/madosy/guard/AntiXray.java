package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AntiXray implements Listener {
    private record Ev(long t, double w, boolean ore) { }

    private static final class Prof {
        final ArrayDeque<Ev> evs = new ArrayDeque<>();
        final LinkedHashSet<Long> broken = new LinkedHashSet<>();
        double vl;
        long lastAlert;
    }

    private static final BlockFace[] FACES = {BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH,
            BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private final MadosyGuard plugin;
    private final Map<UUID, Prof> profs = new ConcurrentHashMap<>();
    private final Set<Material> rare = EnumSet.noneOf(Material.class);
    private final Set<Material> base = EnumSet.noneOf(Material.class);

    public AntiXray(MadosyGuard plugin) {
        this.plugin = plugin;
        reloadSets();
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Prof p : profs.values()) p.vl = Math.max(0, p.vl - 1.0);
        }, 20L * 60, 20L * 60);
    }

    public void reloadSets() {
        rare.clear();
        base.clear();
        for (String s : plugin.getConfig().getStringList("antixray.rare-ores")) {
            Material m = Material.matchMaterial(s);
            if (m != null) rare.add(m);
        }
        for (String s : plugin.getConfig().getStringList("antixray.baseline-blocks")) {
            Material m = Material.matchMaterial(s);
            if (m != null) base.add(m);
        }
    }

    public String report(UUID id) {
        Prof pr = profs.get(id);
        if (pr == null) return "لا توجد بيانات.";
        long window = plugin.getConfig().getLong("antixray.window-minutes", 15) * 60_000L;
        prune(pr, System.currentTimeMillis(), window);
        int stone = 0, ores = 0;
        double score = 0;
        for (Ev ev : pr.evs) {
            if (ev.ore()) { ores++; score += ev.w(); } else stone++;
        }
        double ratio = stone == 0 ? 0 : score / stone;
        return "حجارة=" + stone + " خامات=" + ores + " النسبة=" + String.format("%.3f", ratio)
                + " VL=" + String.format("%.1f", pr.vl);
    }

    private void prune(Prof pr, long now, long window) {
        Iterator<Ev> it = pr.evs.iterator();
        while (it.hasNext()) {
            if (now - it.next().t() > window) it.remove(); else break;
        }
    }

    private void remember(Prof pr, Block b) {
        pr.broken.add(b.getBlockKey());
        if (pr.broken.size() > 400) {
            Iterator<Long> it = pr.broken.iterator();
            it.next();
            it.remove();
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("antixray.enabled", true)) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (p.hasPermission("madosyguard.bypass")) return;

        Block b = e.getBlock();
        Material m = b.getType();
        boolean isRare = rare.contains(m);
        boolean isBase = base.contains(m);
        Prof pr = profs.computeIfAbsent(p.getUniqueId(), k -> new Prof());
        if (!isRare && !isBase) { remember(pr, b); return; }

        long now = System.currentTimeMillis();
        long window = c.getLong("antixray.window-minutes", 15) * 60_000L;
        prune(pr, now, window);

        if (isBase) {
            pr.evs.addLast(new Ev(now, 1.0, false));
            remember(pr, b);
            return;
        }

        // rare ore: is it exposed to NATURAL air/liquid? (air the player dug himself does not count)
        boolean naturalExposure = false;
        for (BlockFace f : FACES) {
            Block nb = b.getRelative(f);
            if ((nb.getType().isAir() || nb.isLiquid()) && !pr.broken.contains(nb.getBlockKey())) {
                naturalExposure = true;
                break;
            }
        }
        pr.evs.addLast(new Ev(now, naturalExposure ? 0.25 : 1.0, true));
        remember(pr, b);
        evaluate(p, pr, b, now);
    }

    private void evaluate(Player p, Prof pr, Block b, long now) {
        FileConfiguration c = plugin.getConfig();
        int stone = 0, ores = 0;
        double score = 0;
        for (Ev ev : pr.evs) {
            if (ev.ore()) { ores++; score += ev.w(); } else stone++;
        }
        if (stone < c.getInt("antixray.min-stone-blocks", 40) || ores < c.getInt("antixray.min-rare-ores", 3)) return;
        double ratio = score / stone;
        if (ratio < c.getDouble("antixray.ratio-threshold", 0.06)) return;

        pr.vl += 1.0 + Math.min(3.0, ratio * 20.0);
        if (pr.vl >= c.getDouble("antixray.alert-vl", 4.0) && now - pr.lastAlert > 15_000) {
            pr.lastAlert = now;
            plugin.alert("AntiXray", p.getName() + " خامات نادرة مشبوهة: " + ores + " خامة / " + stone
                    + " حجر (نسبة " + String.format("%.3f", ratio) + ") VL " + String.format("%.1f", pr.vl)
                    + " @ " + b.getWorld().getName() + " " + b.getX() + "," + b.getY() + "," + b.getZ());
        }
        double kick = c.getDouble("antixray.kick-vl", 0);
        if (kick > 0 && pr.vl >= kick) {
            p.kick(MadosyGuard.mm("<red>تم طردك: اشتباه X-Ray."));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        // keep data for 15 min window; just trim memory when the profile is empty
        Prof pr = profs.get(e.getPlayer().getUniqueId());
        if (pr != null && pr.evs.isEmpty()) profs.remove(e.getPlayer().getUniqueId());
    }
}
