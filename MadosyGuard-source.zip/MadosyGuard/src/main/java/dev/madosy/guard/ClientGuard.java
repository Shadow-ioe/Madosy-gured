package dev.madosy.guard;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRegisterChannelEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Minimap / radar control:
 *  1) sends the "disable" control codes that Xaero / JourneyMap / VoxelMap style mods obey
 *  2) detects mods that register their plugin channels (alert or kick).
 */
public final class ClientGuard implements Listener {
    private final MadosyGuard plugin;
    private final Map<UUID, Set<String>> seen = new ConcurrentHashMap<>();

    public ClientGuard(MadosyGuard plugin) { this.plugin = plugin; }

    private boolean skip(Player p) {
        return !plugin.getConfig().getBoolean("client.enabled", true)
                || p.hasPermission("madosyguard.bypass") || plugin.isExempt(p.getName());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> sendCodes(p), 40L);
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> sendCodes(p), 10L);
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { seen.remove(e.getPlayer().getUniqueId()); }

    private void sendCodes(Player p) {
        if (!p.isOnline() || skip(p)) return;
        if (!plugin.getConfig().getBoolean("client.send-disable-codes", true)) return;
        for (String code : plugin.getConfig().getStringList("client.minimap-codes")) {
            if (code.isBlank()) continue;
            // raw literal text: the section signs must reach the client untouched
            p.sendMessage(Component.text(code.replace('&', '\u00a7')));
        }
    }

    @EventHandler
    public void onChannel(PlayerRegisterChannelEvent e) {
        Player p = e.getPlayer();
        if (skip(p)) return;
        String ch = e.getChannel().toLowerCase(Locale.ROOT);
        for (String key : plugin.getConfig().getStringList("client.detect-channels")) {
            String k = key.toLowerCase(Locale.ROOT);
            if (k.isBlank() || !ch.contains(k)) continue;
            Set<String> s = seen.computeIfAbsent(p.getUniqueId(), x -> new HashSet<>());
            if (!s.add(k)) return;
            plugin.alert("Client", p.getName() + " عنده مود: " + k + " (قناة " + e.getChannel() + ")");
            String action = plugin.getConfig().getString("client.detect-action", "alert");
            if (action.equalsIgnoreCase("kick")) {
                Bukkit.getScheduler().runTask(plugin, () ->
                        p.kick(MadosyGuard.mm("<red>هذا المود غير مسموح بالسيرفر: " + k)));
            }
            return;
        }
    }
}
