package dev.madosy.guard;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MovementCheck implements Listener {
    private static final class St {
        Location lastSafe;
        int hover;
        double airStartY;
        long exemptUntil;
        double vl;
        long lastAlert;
    }

    private final MadosyGuard plugin;
    private final Map<UUID, St> states = new ConcurrentHashMap<>();

    public MovementCheck(MadosyGuard plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (St s : states.values()) s.vl = Math.max(0, s.vl - 0.25);
        }, 20L, 20L);
    }

    public double vl(UUID id) {
        St s = states.get(id);
        return s == null ? 0 : s.vl;
    }

    private St st(Player p) { return states.computeIfAbsent(p.getUniqueId(), k -> new St()); }

    private void exempt(Player p, long ms) { st(p).exemptUntil = System.currentTimeMillis() + ms; }

    // ---------------------------------------------------------------- exemption events
    @EventHandler public void onVelocity(PlayerVelocityEvent e) { exempt(e.getPlayer(), 2500); }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        St s = st(e.getPlayer());
        s.exemptUntil = System.currentTimeMillis() + 2000;
        s.lastSafe = e.getTo().clone();
        s.hover = 0;
        s.airStartY = e.getTo().getY();
    }

    @EventHandler public void onRespawn(PlayerRespawnEvent e) { exempt(e.getPlayer(), 3000); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { exempt(e.getPlayer(), 3000); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { states.remove(e.getPlayer().getUniqueId()); }

    // ---------------------------------------------------------------- main check
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        var cfg = plugin.getConfig();
        if (!cfg.getBoolean("movement.enabled", true)) return;
        Location from = e.getFrom(), to = e.getTo();
        if (to == null) return;
        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) return;

        Player p = e.getPlayer();
        St s = st(p);
        long now = System.currentTimeMillis();
        if (s.lastSafe == null) { s.lastSafe = from.clone(); s.airStartY = from.getY(); }

        boolean sup = supported(to);
        if (isExempt(p, to, s, now)) {
            s.hover = 0;
            s.airStartY = to.getY();
            if (sup) s.lastSafe = to.clone();
            return;
        }

        String flag = null;
        if (sup) {
            s.hover = 0;
            s.airStartY = to.getY();
            s.lastSafe = to.clone();
        } else if (cfg.getBoolean("movement.fly.enabled", true)) {
            double dy = to.getY() - from.getY();
            int jb = amp(p, PotionEffectType.JUMP_BOOST);
            double maxRise = cfg.getDouble("movement.fly.max-rise", 1.35) + 0.5 * jb + 0.15;
            if (to.getY() - s.airStartY > maxRise) {
                flag = "Fly (ارتفاع)";
            } else {
                if (dy > -0.1) s.hover++; else s.hover = 0;
                if (s.hover >= cfg.getInt("movement.fly.hover-ticks", 12) + 3 * jb) flag = "Fly (تعليق)";
            }
        }

        if (flag == null && cfg.getBoolean("movement.speed.enabled", true)) {
            if (onFastSurface(to)) {
                s.exemptUntil = now + 1500;
            } else {
                double h = Math.hypot(to.getX() - from.getX(), to.getZ() - from.getZ());
                double max = cfg.getDouble("movement.speed.max-horizontal", 0.75)
                        * (p.getWalkSpeed() / 0.2) * (1.0 + 0.2 * amp(p, PotionEffectType.SPEED));
                if (h > max) flag = "Speed (" + String.format("%.2f", h) + ")";
            }
        }

        if (flag != null && !boatOrShulkerNear(p)) violation(p, s, e, flag, now);
    }

    private void violation(Player p, St s, PlayerMoveEvent e, String flag, long now) {
        var cfg = plugin.getConfig();
        s.vl += 1.0;
        if (s.vl >= cfg.getDouble("movement.alert-vl", 5.0) && now - s.lastAlert > 5000) {
            s.lastAlert = now;
            plugin.alert("Movement", p.getName() + " → " + flag + " VL " + String.format("%.1f", s.vl));
        }
        double setback = cfg.getDouble("movement.setback-vl", 3.0);
        if (s.vl >= setback) {
            e.setCancelled(true);
            if (s.lastSafe != null && s.vl >= setback + 3) p.teleport(s.lastSafe);
        }
        double kick = cfg.getDouble("movement.kick-vl", 30.0);
        if (kick > 0 && s.vl >= kick) {
            p.kick(MadosyGuard.mm("<red>تم طردك: حركة غير طبيعية (Fly/Speed)."));
        }
    }

    // ---------------------------------------------------------------- helpers
    private int amp(Player p, PotionEffectType t) {
        PotionEffect pe = p.getPotionEffect(t);
        return pe == null ? 0 : pe.getAmplifier() + 1;
    }

    private boolean isExempt(Player p, Location to, St s, long now) {
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getAllowFlight() || p.isFlying() || p.isGliding() || p.isInsideVehicle() || p.isRiptiding()) return true;
        if (p.hasPermission("madosyguard.bypass")) return true;
        if (now < s.exemptUntil) return true;
        if (p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return true;
        Block feet = to.getBlock();
        Block head = to.clone().add(0, 1, 0).getBlock();
        Block below = to.clone().add(0, -0.5, 0).getBlock();
        return special(feet.getType()) || special(head.getType()) || special(below.getType())
                || feet.isLiquid() || head.isLiquid() || below.isLiquid();
    }

    private boolean special(Material t) {
        return Tag.CLIMBABLE.isTagged(t) || t == Material.COBWEB || t == Material.SWEET_BERRY_BUSH
                || t == Material.POWDER_SNOW || t == Material.HONEY_BLOCK || t == Material.SLIME_BLOCK
                || t == Material.BUBBLE_COLUMN || t == Material.SCAFFOLDING;
    }

    private boolean onFastSurface(Location l) {
        Material t = l.clone().add(0, -0.5, 0).getBlock().getType();
        return t == Material.ICE || t == Material.PACKED_ICE || t == Material.BLUE_ICE || t == Material.FROSTED_ICE;
    }

    private boolean supported(Location l) {
        double[] o = {-0.31, 0, 0.31};
        for (double dx : o) {
            for (double dz : o) {
                Block b = l.clone().add(dx, -0.08, dz).getBlock();
                if (!b.isPassable() || b.isLiquid()) return true;
                Material t = l.clone().add(dx, -0.58, dz).getBlock().getType();
                if (Tag.FENCES.isTagged(t) || Tag.WALLS.isTagged(t) || Tag.FENCE_GATES.isTagged(t)) return true;
            }
        }
        return false;
    }

    private boolean boatOrShulkerNear(Player p) {
        for (Entity en : p.getNearbyEntities(1.5, 2, 1.5)) {
            String n = en.getType().name();
            if (n.contains("BOAT") || n.equals("SHULKER") || n.contains("MINECART")) return true;
        }
        return false;
    }
}
